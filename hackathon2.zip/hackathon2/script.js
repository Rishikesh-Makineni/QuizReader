// Sample question data
const questions = [
    "What are the main causes of electrical hazards?",
    "How can you prevent slips and falls on wet surfaces?",
    "What safety measures should be taken near heavy machinery?",
    "Describe the procedure for handling chemical spills.",
    "What are the key steps in fire safety protocols?"
];

let currentIndex = 0;
let autoNextInterval = null;

// Show the next question when "Next" button is clicked
document.getElementById('next-btn').addEventListener('click', function() {
    showNextQuestion();
});

// Stop the automatic question display when "Stop" button is clicked
document.getElementById('settings-btn').addEventListener('click', function() {
    clearInterval(autoNextInterval);
    autoNextInterval = null;
    document.getElementById('question-text').textContent = "Auto-switching stopped.";
});

// Show the next question function
function showNextQuestion() {
    currentIndex = (currentIndex + 1) % questions.length;
    document.getElementById('question-text').textContent = questions[currentIndex];
}

// Automatically display next question based on speed control
document.getElementById('speed').addEventListener('input', function() {
    if (autoNextInterval) clearInterval(autoNextInterval);
    const speed = parseInt(this.value) * 1000;
    autoNextInterval = setInterval(showNextQuestion, speed);
});

// Trigger BUZZ and show timer
document.getElementById('buzz-btn').addEventListener('click', function() {
    let timer = 5;
    const interval = setInterval(() => {
        document.getElementById('question-text').textContent = `Timer: ${timer} seconds remaining...`;
        if (timer === 0) {
            clearInterval(interval);
            document.getElementById('question-text').textContent = "Time's up!";
        }
        timer--;
    }, 1000);
});

// Function to update the leaderboard table
function updateLeaderboard() {
    leaderboardTable.innerHTML = ''; // Clear the table before updating
    leaderboard.forEach((player) => {
        const row = document.createElement('tr');
        row.innerHTML = `<td>${player.name}</td><td>${player.score}</td>`;
        leaderboardTable.appendChild(row);
    });
}

// Rewind button functionality to remove the last added player
document.getElementById('rewind-btn').addEventListener('click', () => {
    // Rewind the leaderboard to remove the last player added
    leaderboard.pop();
    updateLeaderboard();
});

// Start automatic question display at initial speed
document.getElementById('speed').dispatchEvent(new Event('input'));